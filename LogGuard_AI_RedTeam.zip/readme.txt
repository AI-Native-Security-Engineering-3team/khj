사용법

압축해제후 해제한 폴더를 powershell로 실행

py -3 .\LogGuard_AI_RedTeam_v2.py --mode ai --interval 5 --cycles 50		//		5초에 한번씩 50번 공격