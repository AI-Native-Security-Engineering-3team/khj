@echo off
setlocal
if not exist "%~dp0AI_SERVER_ATTACKER_random_ip_MENU.py" (
    echo [ERROR] Script not found in launcher folder.
    pause
    exit /b 1
)
start "AI SERVER ATTACKER" powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_AI_SERVER_ATTACKER_random_ip_MENU.ps1"
exit /b 0
