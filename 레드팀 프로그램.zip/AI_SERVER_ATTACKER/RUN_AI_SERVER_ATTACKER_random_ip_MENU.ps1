# PowerShell launcher: avoids CMD's "Terminate batch job (Y/N)?" Ctrl+C handling.
$ErrorActionPreference = 'Stop'
try {
    Set-Location -LiteralPath $PSScriptRoot
    $name = 'AI_SERVER_ATTACKER_random_ip_MENU.py'
    if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot $name))) {
        throw "Missing Python script: $name"
    }
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py -3 ".\$name" @args
    } elseif (Get-Command python -ErrorAction SilentlyContinue) {
        & python ".\$name" @args
    } else {
        throw 'Python 3 not installed or missing from PATH'
    }
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[INFO] Python exit code: $LASTEXITCODE"
        Read-Host 'Press Enter to close this window' | Out-Null
    }
} catch {
    Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red
    Read-Host 'Press Enter to close this window' | Out-Null
    exit 1
}
