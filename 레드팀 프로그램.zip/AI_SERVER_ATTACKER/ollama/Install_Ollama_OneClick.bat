@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Ollama One-Click Setup - Qwen2.5 3B
cd /d "%~dp0"

set "MODEL=qwen2.5:3b"
set "OLLAMA_EXE="

echo.
echo ===============================================
echo     OLLAMA ONE-CLICK SETUP - QWEN2.5 3B
echo ===============================================
echo.
echo [INFO] This setup installs Ollama only if missing.
echo [INFO] It will download the %MODEL% model.
echo [INFO] Ollama stays local at 127.0.0.1:11434.
echo.

rem Use the per-user install path first to avoid an outdated PATH.
if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" set "OLLAMA_EXE=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"
if not defined OLLAMA_EXE (
    where ollama.exe >nul 2>&1
    if not errorlevel 1 set "OLLAMA_EXE=ollama.exe"
)

if not defined OLLAMA_EXE (
    echo [1/4] Ollama is not installed. Installing with winget...
    where winget.exe >nul 2>&1
    if errorlevel 1 goto :no_winget
    winget install --id Ollama.Ollama --exact --source winget --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo [ERROR] winget installation failed. Check the message above.
        goto :fail
    )
    if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" set "OLLAMA_EXE=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"
    if not defined OLLAMA_EXE (
        where ollama.exe >nul 2>&1
        if not errorlevel 1 set "OLLAMA_EXE=ollama.exe"
    )
    if not defined OLLAMA_EXE (
        echo [ERROR] Ollama was installed but the CLI was not found.
        echo [TIP] Sign out and back in, then run this BAT again.
        goto :fail
    )
) else (
    echo [1/4] Ollama already installed. Skipping installation.
)

echo [2/4] Checking local Ollama API...
powershell.exe -NoProfile -NonInteractive -Command "try { Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/version' -TimeoutSec 3 | Out-Null; exit 0 } catch { exit 1 }" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Starting Ollama background server...
    start "" /min "%OLLAMA_EXE%" serve
)

for /l %%N in (1,1,30) do (
    powershell.exe -NoProfile -NonInteractive -Command "try { Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/version' -TimeoutSec 2 | Out-Null; exit 0 } catch { exit 1 }" >nul 2>&1
    if not errorlevel 1 goto :server_ready
    timeout /t 1 /nobreak >nul
)
echo [ERROR] Ollama API did not start on 127.0.0.1:11434.
echo [TIP] Check whether another app is using TCP port 11434.
goto :fail

:server_ready
echo [OK] Ollama API is ready.
echo.
echo [3/4] Checking model %MODEL%...
"%OLLAMA_EXE%" list | findstr /i /b /c:"%MODEL%" >nul 2>&1
if not errorlevel 1 (
    echo [OK] Model already downloaded.
) else (
    echo [INFO] Downloading %MODEL% - about 1.9 GB.
    "%OLLAMA_EXE%" pull "%MODEL%"
    if errorlevel 1 (
        echo [ERROR] Model download failed. Check your internet connection and free disk space.
        goto :fail
    )
)

echo.
echo [4/4] Testing a short model response...
powershell.exe -NoProfile -NonInteractive -Command "try { $payload = @{ model='qwen2.5:3b'; prompt='Reply OK'; stream=$false; options=@{num_predict=8} } | ConvertTo-Json -Depth 5; $r = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/generate' -Method Post -ContentType 'application/json' -Body $payload -TimeoutSec 180; if ($null -ne $r.response) { exit 0 } else { exit 1 } } catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 (
    echo [WARN] Ollama is installed, but model generation did not pass the test.
    echo [TIP] Run: "%OLLAMA_EXE%" run "%MODEL%"
    goto :fail
)

echo.
echo ===============================================
echo  SUCCESS: Ollama and %MODEL% are ready.
echo  API: http://127.0.0.1:11434
echo  AI_SERVER_ATTACKER can now use the local AI.
echo ===============================================
echo.
pause
exit /b 0

:no_winget
echo [ERROR] winget is not available on this PC.
echo [TIP] Install Microsoft App Installer or download Ollama from the official website:
echo       https://ollama.com/download/windows
start "" "https://ollama.com/download/windows"
goto :fail

:fail
echo.
echo [SETUP NOT COMPLETED] Review the error above and try again.
echo.
pause
exit /b 1
